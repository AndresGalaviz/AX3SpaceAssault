package com.me.spaceassault.resources;

import com.badlogic.gdx.tools.imagepacker.TexturePacker2;

public class TexturePacket {

	public static void main(String[] args) {
		TexturePacker2.process("/Users/AndresG/Dropbox/ITESM/04 - Cuarto Semestre Ene - May 2014/Videojuegos/Final project/Game/AX3SpaceAssault/SpaceAssault-android/assets/images/characterpng/jump", "/Users/AndresG/Dropbox/ITESM/04 - Cuarto Semestre Ene - May 2014/Videojuegos/Final project/Game/AX3SpaceAssault/SpaceAssault-android/assets/images/characterpng/jump", "jump.pack");
	}
}