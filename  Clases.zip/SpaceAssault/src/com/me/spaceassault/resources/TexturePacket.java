package com.me.spaceassault.resources;

import com.badlogic.gdx.tools.imagepacker.TexturePacker2;
/**
 * Clase <I>TexturePacket</I> que se utiliza para crear textures
 * @author AndresG
 *
 */
public class TexturePacket {

	public static void main(String[] args) {
		TexturePacker2.process("C:/Users/Alberto/Documents/Tec/4 Semestre/Proyecto de desarrollo de videojuegos/AX3SpaceAssault/SpaceAssault-android/assets/images/numbers", "C:/Users/Alberto/Documents/Tec/4 Semestre/Proyecto de desarrollo de videojuegos/AX3SpaceAssault/SpaceAssault-android/assets/images/numbers", "numbers.pack");
	}
}